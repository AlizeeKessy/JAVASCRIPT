/*
Exercice 8:
Les habitants de Zorglub paient l’impôt selon les règles suivantes :
 les hommes de plus de 20 ans paient l’impôt
 les femmes paient l’impôt si elles ont entre 18 et 35 ans
 les autres ne paient pas d’impôt
Le programme demandera donc l’âge et le sexe du Zorglubien, 
et se prononcera donc ensuite sur le fait que l’habitant est imposable.
*/


let age = 0;
let iIntervalAge_1= 0;
iIntervalAge_1+=iAge;
let iIntervalAge_2= 0;
iIntervalAge_2+=iAge;

let bGenre = confirm("Êtes vous un Homme (OK)/ une Femme (Annuler)?");
//Algo pour savoir si vous êtes un homme et si vous êtes impossable
if (bGenre==true) {
  alert("Vous êtes un Homme");
} else {
  console.log("Vous êtes une Femme");
  alert("Vous êtes une femme");
}

let iAge = parseInt(prompt("Entrer votre âge"));
age += iAge

if (age > 20) {
  
  console.log("Vous êtes Imposable");
  alert("Vous êtes Imposable");
} else {
  console.log("Vous n'êtes pas Imposable");
  alert("Vous n'êtes pas Imposable");
}

//Algo pour savoir si une femme est impossable
if (bGenre=false){
  iIntervalAge_1 > 17;
  console.log("Vous êtes Imposable");
  alert("Vous êtes Imposable");
} else if (bGenre=false){
  iIntervalAge_1 < 3;
  console.log("Vous êtes Imposable");
  alert("Vous êtes Imposable");
} else {
  console.log("Vous n'êtes pas Imposable");
  alert("Vous n'êtes pas Imposable");
} 
